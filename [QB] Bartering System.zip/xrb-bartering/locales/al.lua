-- locales/al.lua
-- This file is less critical now as messages are directly pulled from Config.Messages.
-- You would only need this if you were adapting the script to use QBCore's Lang() functions
-- or adding language keys not present in the Config.

-- Example if you were using Lang():
-- Lang = Lang or {}
-- Lang['al'] = Lang['al'] or {}

-- Lang['al']['some_new_message_key'] = "Ky eshte nje mesazh i ri."

-- You could still copy Config.Messages here for reference if desired, but it's not directly used by the script as converted.